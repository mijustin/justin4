![Brutal](https://github.com/mijustin/brutal-theme/blob/master/brutal-logo.png)

# Brutal theme
A brutalist WordPress theme

A theme inspired by two of my essays:
- [This is a web page](https://justinjackson.ca/words.html)
- [I'm a fucking websmaster](https://justinjackson.ca/websmaster)

The original design came from [Kyle Fox](https://github.com/kylefox). I applied his design and modified it for use as a WordPress theme.

But I want it to be better.

Specifically, the index page could use some work. If you'd like to help, please submit a PR!

(You're free to use this theme on your site.)
